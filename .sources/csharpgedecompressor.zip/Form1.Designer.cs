﻿namespace CSharpGEDecompressor
{
    partial class CSharpGEDecomprssor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDecompress = new System.Windows.Forms.Button();
            this.buttonCompress = new System.Windows.Forms.Button();
            this.comboBoxGame = new System.Windows.Forms.ComboBox();
            this.buttonCompressEncrypted = new System.Windows.Forms.Button();
            this.buttonDecompressEncrypted = new System.Windows.Forms.Button();
            this.labelFileNumber = new System.Windows.Forms.Label();
            this.textBoxFileNumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonDecompress
            // 
            this.buttonDecompress.Location = new System.Drawing.Point(168, 12);
            this.buttonDecompress.Name = "buttonDecompress";
            this.buttonDecompress.Size = new System.Drawing.Size(150, 31);
            this.buttonDecompress.TabIndex = 0;
            this.buttonDecompress.Text = "Decompress";
            this.buttonDecompress.UseVisualStyleBackColor = true;
            this.buttonDecompress.Click += new System.EventHandler(this.buttonDecompress_Click);
            // 
            // buttonCompress
            // 
            this.buttonCompress.Location = new System.Drawing.Point(324, 12);
            this.buttonCompress.Name = "buttonCompress";
            this.buttonCompress.Size = new System.Drawing.Size(150, 31);
            this.buttonCompress.TabIndex = 1;
            this.buttonCompress.Text = "Compress";
            this.buttonCompress.UseVisualStyleBackColor = true;
            this.buttonCompress.Click += new System.EventHandler(this.buttonCompress_Click);
            // 
            // comboBoxGame
            // 
            this.comboBoxGame.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGame.FormattingEnabled = true;
            this.comboBoxGame.Items.AddRange(new object[] {
            "GOLDENEYE",
            "PD",
            "BANJOKAZOOIE",
            "KILLERINSTINCT",
            "DONKEYKONG64",
            "BLASTCORPS",
            "BANJOTOOIE",
            "DONKEYKONG64KIOSK",
            "CONKER",
            "TOPGEARRALLY",
            "MILO",
            "JFG",
            "DKR",
            "JFGKIOSK",
            "MICKEYSPEEDWAY",
            "MORTALKOMBAT",
            "STUNTRACER64"});
            this.comboBoxGame.Location = new System.Drawing.Point(12, 12);
            this.comboBoxGame.Name = "comboBoxGame";
            this.comboBoxGame.Size = new System.Drawing.Size(150, 24);
            this.comboBoxGame.TabIndex = 2;
            this.comboBoxGame.SelectedIndexChanged += new System.EventHandler(this.comboBoxGame_SelectedIndexChanged);
            // 
            // buttonCompressEncrypted
            // 
            this.buttonCompressEncrypted.Location = new System.Drawing.Point(324, 49);
            this.buttonCompressEncrypted.Name = "buttonCompressEncrypted";
            this.buttonCompressEncrypted.Size = new System.Drawing.Size(150, 47);
            this.buttonCompressEncrypted.TabIndex = 4;
            this.buttonCompressEncrypted.Text = "Compress Encrypted";
            this.buttonCompressEncrypted.UseVisualStyleBackColor = true;
            this.buttonCompressEncrypted.Visible = false;
            this.buttonCompressEncrypted.Click += new System.EventHandler(this.buttonCompressEncrypted_Click);
            // 
            // buttonDecompressEncrypted
            // 
            this.buttonDecompressEncrypted.Location = new System.Drawing.Point(168, 49);
            this.buttonDecompressEncrypted.Name = "buttonDecompressEncrypted";
            this.buttonDecompressEncrypted.Size = new System.Drawing.Size(150, 47);
            this.buttonDecompressEncrypted.TabIndex = 3;
            this.buttonDecompressEncrypted.Text = "Decompress Encrypted";
            this.buttonDecompressEncrypted.UseVisualStyleBackColor = true;
            this.buttonDecompressEncrypted.Visible = false;
            this.buttonDecompressEncrypted.Click += new System.EventHandler(this.buttonDecompressEncrypted_Click);
            // 
            // labelFileNumber
            // 
            this.labelFileNumber.AutoSize = true;
            this.labelFileNumber.Location = new System.Drawing.Point(480, 56);
            this.labelFileNumber.Name = "labelFileNumber";
            this.labelFileNumber.Size = new System.Drawing.Size(122, 17);
            this.labelFileNumber.TabIndex = 5;
            this.labelFileNumber.Text = "File Number (Hex)";
            this.labelFileNumber.Visible = false;
            // 
            // textBoxFileNumber
            // 
            this.textBoxFileNumber.Location = new System.Drawing.Point(610, 53);
            this.textBoxFileNumber.Name = "textBoxFileNumber";
            this.textBoxFileNumber.Size = new System.Drawing.Size(58, 22);
            this.textBoxFileNumber.TabIndex = 6;
            this.textBoxFileNumber.Text = "0A02";
            this.textBoxFileNumber.Visible = false;
            // 
            // CSharpGEDecomprssor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(728, 108);
            this.Controls.Add(this.textBoxFileNumber);
            this.Controls.Add(this.labelFileNumber);
            this.Controls.Add(this.buttonCompressEncrypted);
            this.Controls.Add(this.buttonDecompressEncrypted);
            this.Controls.Add(this.comboBoxGame);
            this.Controls.Add(this.buttonCompress);
            this.Controls.Add(this.buttonDecompress);
            this.Name = "CSharpGEDecomprssor";
            this.Text = "C# GE Decompressor (by SubDrag, port of MrHTFord\'s work)";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonDecompress;
        private System.Windows.Forms.Button buttonCompress;
        private System.Windows.Forms.ComboBox comboBoxGame;
        private System.Windows.Forms.Button buttonCompressEncrypted;
        private System.Windows.Forms.Button buttonDecompressEncrypted;
        private System.Windows.Forms.Label labelFileNumber;
        private System.Windows.Forms.TextBox textBoxFileNumber;
    }
}

