﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSharpGEDecompressor
{
    public static class BTDecryption
    {

        public static void DecryptBTFile(int fileNumber, Byte[] input, Byte[] output, int size)
        {
	        SByte[] rsp = new SByte[0x20]; 

	        Byte[] inputKey = new Byte[0x10];

	        Int16 key = (Int16)(fileNumber - 0x955);

	        Int32 A2 = 0x10;
	        for (Int32 V1 = 0; V1 < 0xE; V1+=2)
	        {

		        Int32 T6 = key >> V1;
		        Int32 T7 = A2 - V1;
		        Int32 T8 = key << T7;

		        Int32 T9 = T6 | T8;

		        inputKey[V1] = (Byte)((T9) & 0xFF);
		        inputKey[V1+1] = (Byte)((T9 & 0xFF00) & 0xFF);
	        }

	        inputKey[0x0E] = 0x00;
	        inputKey[0x0F] = 0x02;

	        SByte[] nibbleKeyVersion = new SByte[0x20];
	        for (int x = 0; x < 0x20; x++)
	        {
		        if ((x % 2) == 0)
			        nibbleKeyVersion[x] = (SByte)((inputKey[x/2] >> 4) & 0xF);
		        else
                    nibbleKeyVersion[x] = (SByte)((inputKey[x / 2]) & 0xF);
	        }

            n64_cic_nus_6105.GenerateCICResult(nibbleKeyVersion, rsp, 0x20 - 2);
            rsp[0x20 - 2] = 0x0;
            rsp[0x20 - 1] = 0x0;

	        Byte[] cicValue = new Byte[0x10];
	        for (int x = 0; x < 0x20; x+=2)
	        {
                cicValue[x / 2] = (Byte)(((Byte)rsp[x] << 4) | (Byte)rsp[x + 1]);
	        }

	        for (int x = 0; x < size; x++)
	        {
		        Byte value = input[x];
		        output[x] = (Byte)(value ^ cicValue[x % 0xE]);
	        }
        }
    }
}
