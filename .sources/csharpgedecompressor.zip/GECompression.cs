﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace CSharpGEDecompressor
{
    public class GECompression
    {
        UInt32 maxByteSize = 0x800000;

        static public int GOLDENEYE = 0;
        static public int PD = 1;
        static public int BANJOKAZOOIE = 2;
        static public int KILLERINSTINCT = 3;
        static public int DONKEYKONG64 = 4;
        static public int BLASTCORPS = 5;
        static public int BANJOTOOIE = 6;
        static public int DONKEYKONG64KIOSK = 7;
        static public int CONKER = 8;
        static public int TOPGEARRALLY = 9;
        static public int MILO = 10;
        static public int JFG = 11;
        static public int DKR = 12;
        static public int JFGKIOSK = 13;
        static public int MICKEYSPEEDWAY = 14;
        static public int MORTALKOMBAT = 15;
        static public int STUNTRACER64 = 16;

        public struct tableEntry {
	        public UInt32 bits;
	        public Byte flags;
	        public int nextIndex;
	        public UInt32 wordValue;
        };

        int game;
	    String mainFolder;

	    /*static Byte[] bt1Table1 = new Byte[288];
	    static Byte[] bt1Table2 = new Byte[30];

	    static UInt16[] bt12Table1S = new UInt16[0x20];
	    static UInt16[] bt12Table1B = new UInt16[0x20];
	    static UInt16[] bt12Table2S = new UInt16[0x20];
	    static UInt16[] bt12Table2B = new UInt16[0x20];

	    static Byte[] bt2Table1B = new Byte[0x13];*/

	    tableEntry[] unpackTable;
	    int unpackTableIndex;

	    UInt32 bitsCache;
	    int bitsRemain;
	    UInt32 bytesIndex;

	    Byte[] compressedBuffer;
	    int compressedBufferSize;

	    Byte[] variableTable = new Byte[0x13];
	    UInt16 tableSize;
	    Byte fiveBits;
	    UInt32[] wordTable;

	    UInt32 iterationCounter;

	    int TABLE1 = 0;
	    int TABLE2 = 1;
	    int VARIABLETABLE = 2;
	    int WORDTABLEBEGIN = 3;
	    int WORDTABLEEND = 4;

        public GECompression()
        {
            compressedBuffer = null;
            compressedBufferSize = 0;
            wordTable = null;
            unpackTable = null;
            game = GOLDENEYE;

            unpackTable = new tableEntry[0xFFFF];
        }

        Byte[] bt1Table1 = new Byte[288] 
        {
            8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8
        };
        Byte[] bt1Table2 = new Byte[30]
        {
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5
        };

        UInt16[] bt12Table1S = new UInt16[0x20] 
        {
            0x0003, 0x0004, 0x0005, 0x0006, 0x0007, 0x0008, 0x0009, 0x000a,
            0x000b, 0x000d, 0x000f, 0x0011, 0x0013, 0x0017, 0x001b, 0x001f,
            0x0023, 0x002b, 0x0033, 0x003b, 0x0043, 0x0053, 0x0063, 0x0073,
            0x0083, 0x00a3, 0x00c3, 0x00e3, 0x0102, 0x0000, 0x0000, 0x0000
        };

        UInt16[] bt12Table1B = new UInt16[0x20]
        {
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x01, 0x01, 0x01, 0x01, 0x02, 0x02, 0x02, 0x02,
            0x03, 0x03, 0x03, 0x03, 0x04, 0x04, 0x04, 0x04,
            0x05, 0x05, 0x05, 0x05, 0x00, 0x63, 0x63, 0x00
        };

        UInt16[] bt12Table2S = new UInt16[0x20]
        {
            0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0007, 0x0009, 0x000d,
            0x0011, 0x0019, 0x0021, 0x0031, 0x0041, 0x0061, 0x0081, 0x00c1,
            0x0101, 0x0181, 0x0201, 0x0301, 0x0401, 0x0601, 0x0801, 0x0c01,
            0x1001, 0x1801, 0x2001, 0x3001, 0x4001, 0x6001, 0x0000, 0x0000	

        };

        UInt16[] bt12Table2B = new UInt16[0x20]
        {
            0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x02, 0x02,
            0x03, 0x03, 0x04, 0x04, 0x05, 0x05, 0x06, 0x06,
            0x07, 0x07, 0x08, 0x08, 0x09, 0x09, 0x0a, 0x0a,
            0x0b, 0x0b, 0x0c, 0x0c, 0x0d, 0x0d, 0x00, 0x00
        };

        Byte[] bt2Table1B = new Byte[0x13]
        {
            0x10,0x11,0x12,0x00, 0x08,0x07,0x09,0x06, 0x0a,0x05,0x0b,0x04, 0x0c,0x03,0x0d,0x02, 0x0e,0x01,0x0f
        };

        public void SetPath(String directory)
        {
            /*//To get Directory in MFC
            char tempFolder[8000];
            ::GetCurrentDirectory(8000, tempFolder);
            directory.Format("%s\\", tempFolder);*/

            if (directory.Substring((directory.Length-1), 1) != "\\")
	            mainFolder = directory + "\\";
            else
	            mainFolder = directory;
        }

        public void SetGame(int replaceGame)
        {
            game = replaceGame;
        }

        

        public void SetCompressedBuffer(Byte[] Buffer, int bufferSize)
        {
	        compressedBuffer = new Byte[bufferSize];

            for (int x = 0; x < bufferSize; x++)
            {
	            compressedBuffer[x] = Buffer[x];
            }

            compressedBufferSize = bufferSize;
        }


        UInt32 GetNBits(int nBits)
        {
            while (bitsRemain < nBits)
            {
	            if (bytesIndex >= maxByteSize)
		            return 0; // bad decompression
	            if (bytesIndex >= compressedBufferSize)
		            return 0; // bad decompression
	            bitsCache = ((bitsCache) | ((UInt32)compressedBuffer[bytesIndex] << bitsRemain));
	            bitsRemain = bitsRemain + 8;
	            bytesIndex++;
            }

            UInt32 result = (UInt32)(bitsCache & ((1 << nBits)-1));
            bitsCache = bitsCache >> nBits;
            bitsRemain = bitsRemain - nBits;
            return result;
        }

        UInt32 GetNBitsAndPreserve(int nBits)
        {
            while (bitsRemain < nBits)
            {
	            if (bytesIndex >= maxByteSize)
		            return 0; // bad decompression
	            if (bytesIndex >= compressedBufferSize)
		            return 0; // bad decompression
	            bitsCache = ((bitsCache) | ((UInt32)compressedBuffer[bytesIndex] << bitsRemain));
	            bitsRemain = bitsRemain + 8;
	            bytesIndex++;
            }

            UInt32 result = (UInt32)(bitsCache & ((1 << nBits)-1));
            return result;
        }

        Boolean hiddenExec (String program, String args, String currentDirectory)
        {
            ProcessStartInfo pInfo = new ProcessStartInfo();
            //Set the file name member of the process info structure.
            pInfo.FileName = program;
            pInfo.Arguments = args;
            pInfo.WorkingDirectory = currentDirectory;
            pInfo.CreateNoWindow = true;

            Process p = Process.Start(pInfo);
            p.WaitForExit();

            return true;
        }

        Boolean IsFileExist(String lpszFilename)
        {
            return System.IO.File.Exists(lpszFilename);
        }


        public Boolean CompressGZipFile(String inputFile, String outputFile, Boolean byteFlipCompressed)
        {
            String gzipFileName = (mainFolder + "gzip.exe");
            String tempFileExistName = (mainFolder + "gzip.exe");

            if (IsFileExist(tempFileExistName) == false)
            {
	            MessageBox.Show("gzip.exe not found!", "Error");
	            return false;
            }

            tempFileExistName =  inputFile;
            if (IsFileExist(tempFileExistName))
            {
                FileInfo f = new FileInfo(tempFileExistName);

                UInt32 size = 0;
                Byte[] tempBufferTemp;
                using (BinaryReader b = new BinaryReader(File.Open(tempFileExistName, FileMode.Open, FileAccess.Read, FileShare.Read)))
	            {
	                size = Convert.ToUInt32(b.BaseStream.Length);

                    if (size == 0)
                        return false;

                    tempBufferTemp = b.ReadBytes((Int32)size);

                    
                 }

                Byte[] tempBuffer = new byte[size + 0x10];
                for (int x = 0; x < size + 0x10; x++)
                {
                    tempBuffer[x] = 0x0;
                }

                for (int x = 0; x < size; x++)
                {
                    tempBuffer[x] = tempBufferTemp[x];
                }

                using (BinaryWriter b = new BinaryWriter(File.Open((mainFolder+"tempgh9.bin"), FileMode.Create)))
	            {
	                UInt32 compressedSize = size;

                    if (game != BANJOTOOIE)
                    {
                        if (((compressedSize % 0x10) != 0))
                            compressedSize = ((compressedSize - (compressedSize % 0x10)) + 0x10);
                    }

                    b.Write(tempBuffer, (Int32)0, (Int32)compressedSize);
                }

	            Directory.SetCurrentDirectory(mainFolder);
	            
	            hiddenExec("gzip.exe", "-f -q -9 tempgh9.bin", mainFolder);
	            String outputGZippedName = (mainFolder+"TEMPGH9.BIZ");

	            tempFileExistName = outputGZippedName;
	            if (!IsFileExist(tempFileExistName))
	            {
		            outputGZippedName = (mainFolder+"tempgh9.bin.gz");;
	            }

	            tempFileExistName = outputGZippedName;
	            if (IsFileExist(tempFileExistName))
	            {
                    Byte[] tempBufferNew;
                    int sizeNew;
                    using (BinaryReader b = new BinaryReader(File.Open(outputGZippedName, FileMode.Open, FileAccess.Read, FileShare.Read)))
	                {
	                    sizeNew = Convert.ToInt32(b.BaseStream.Length);

                        if (sizeNew == 0)
                            return false;
		                tempBufferNew = b.ReadBytes((Int32)sizeNew);
                    }

	                File.Delete((mainFolder+"TEMPGH9.BIZ"));

                    using (BinaryWriter b = new BinaryWriter(File.Open(outputFile, FileMode.Create)))
	                {
	                    UInt32 start = 0x16;
	                    if ((game == GOLDENEYE) || (game == KILLERINSTINCT))
	                    {
		                    start = start - 2;
		                    tempBufferNew[start] = 0x11;
		                    tempBufferNew[start+1] = 0x72;
	                    }
	                    else if (game == PD)
	                    {
		                    start = start - 5;
		                    tempBufferNew[start] = 0x11;
		                    tempBufferNew[start+1] = 0x73;
		                    tempBufferNew[start+2] = (Byte)((size >> 16) & 0xFF);
		                    tempBufferNew[start+3] = (Byte)((size >> 8) & 0xFF);
		                    tempBufferNew[start+4] = (Byte)((size) & 0xFF);
	                    }
	                    else if (game == BANJOKAZOOIE)
	                    {
		                    start = start - 6;
		                    tempBufferNew[start] = 0x11;
		                    tempBufferNew[start+1] = 0x72;
		                    tempBufferNew[start+2] = (Byte)((size >> 24) & 0xFF);
		                    tempBufferNew[start+3] = (Byte)((size >> 16) & 0xFF);
		                    tempBufferNew[start+4] = (Byte)((size >> 8) & 0xFF);
		                    tempBufferNew[start+5] = (Byte)((size) & 0xFF);
	                    }
	                    else if ((game == DONKEYKONG64) || (game == BLASTCORPS))
	                    {
		                    start = start - 0xA;
		                    tempBufferNew[start] = 0x1F;
		                    tempBufferNew[start+1] = 0x8B;
		                    tempBufferNew[start+2] = 0x08;
		                    tempBufferNew[start+3] = 0x00;
		                    tempBufferNew[start+4] = 0x00;
		                    tempBufferNew[start+5] = 0x00;
		                    tempBufferNew[start+6] = 0x00;
		                    tempBufferNew[start+7] = 0x00;
		                    tempBufferNew[start+8] = 0x02;
		                    tempBufferNew[start+9] = 0x03;
	                    }
	                    else if (game == DONKEYKONG64KIOSK)
	                    {
		                    start = start - 0x12;
		                    tempBufferNew[start] = 0x1F;
		                    tempBufferNew[start+1] = 0x8B;
		                    tempBufferNew[start+2] = 0x08;
		                    tempBufferNew[start+3] = 0x08;
		                    tempBufferNew[start+4] = 0x03;
		                    tempBufferNew[start+5] = 0x45;
		                    tempBufferNew[start+6] = 0x75;
		                    tempBufferNew[start+7] = 0x37;
		                    tempBufferNew[start+8] = 0x00;
		                    tempBufferNew[start+9] = 0x03;
		                    tempBufferNew[start+0xA] = 0x74;
		                    tempBufferNew[start+0xB] = 0x6D;
		                    tempBufferNew[start+0xC] = 0x70;
		                    tempBufferNew[start+0xD] = 0x2E;
		                    tempBufferNew[start+0xE] = 0x62;
		                    tempBufferNew[start+0xF] = 0x69;
		                    tempBufferNew[start+0x10] = 0x6E;
		                    tempBufferNew[start+0x11] = 0x00;
	                    }
	                    else if (game == BANJOTOOIE)
	                    {

		                    start = start - 2;
		                    // is this checksum, not sure?
                            Double roundedSize = Math.Ceiling((Double)size / (Double)0x10);
                            UInt16 roundedSizeShort = (UInt16)roundedSize;
                            tempBufferNew[start] = (Byte)((roundedSizeShort >> 8) & 0xFF);
                            tempBufferNew[start + 1] = (Byte)((roundedSizeShort) & 0xFF);
	                    }
	                    else if (game == CONKER)
	                    {
		                    start = start - 4;
		                    tempBufferNew[start] = (Byte)((size >> 24) & 0xFF);
		                    tempBufferNew[start+1] = (Byte)((size >> 16) & 0xFF);
		                    tempBufferNew[start+2] = (Byte)((size >> 8) & 0xFF);
		                    tempBufferNew[start+3] = (Byte)((size) & 0xFF);
	                    }
	                    else if (game == TOPGEARRALLY)
	                    {
		                    start = start - 0xE;
		                    // compressed
		                    tempBufferNew[start] = (Byte)(((sizeNew-(start + 8)) >> 24) & 0xFF);
		                    tempBufferNew[start+1] = (Byte)(((sizeNew-(start + 8)) >> 16) & 0xFF);
		                    tempBufferNew[start+2] = (Byte)(((sizeNew-(start + 8)) >> 8) & 0xFF);
		                    tempBufferNew[start+3] = (Byte)(((sizeNew-(start + 8))) & 0xFF);
		                    // uncompressed
		                    tempBufferNew[start+4] = (Byte)((size >> 24) & 0xFF);
		                    tempBufferNew[start+5] = (Byte)((size >> 16) & 0xFF);
		                    tempBufferNew[start+6] = (Byte)((size >> 8) & 0xFF);
		                    tempBufferNew[start+7] = (Byte)((size) & 0xFF);
		                    // ?
		                    tempBufferNew[start+8] = 0x0;
		                    tempBufferNew[start+9] = 0x0;
		                    tempBufferNew[start+0xA] = 0x0;
		                    tempBufferNew[start+0xB] = 0x0;
		                    tempBufferNew[start+0xC] = 0x0;
		                    tempBufferNew[start+0xD] = 0x0;
	                    }
	                    else if (game == MILO)
	                    {
		                    start = start - 2;
		                    tempBufferNew[start] = 0x78;
		                    tempBufferNew[start+1] = 0x9C;
	                    }
	                    else if ((game == JFG) || (game == JFGKIOSK))
	                    {
		                    // unknown 5 bytes
		                    start = start - 5;
		                    tempBufferNew[start] = 0x04;
		                    tempBufferNew[start+1] = 0x03;
		                    tempBufferNew[start+2] = 0x00;
		                    tempBufferNew[start+3] = 0x00;
		                    tempBufferNew[start+4] = 0x09;
	                    }
	                    else if (game == DKR)
	                    {
		                    // unknown 5 bytes
		                    start = start - 5;
		                    tempBufferNew[start] = 0x04;
		                    tempBufferNew[start+1] = 0x03;
		                    tempBufferNew[start+2] = 0x00;
		                    tempBufferNew[start+3] = 0x00;
		                    tempBufferNew[start+4] = 0x09;
	                    }
	                    else if (game == MICKEYSPEEDWAY)
	                    {
		                    // unknown 5 bytes
		                    start = start - 5;
		                    tempBufferNew[start] = 0x04;
		                    tempBufferNew[start+1] = 0x03;
		                    tempBufferNew[start+2] = 0x00;
		                    tempBufferNew[start+3] = 0x00;
		                    tempBufferNew[start+4] = 0x09;
	                    }
	                    else if (game == STUNTRACER64)
	                    {
		                    start = start - 2;
		                    tempBufferNew[start] = 0x78;
		                    tempBufferNew[start+1] = 0xDA;
	                    }



	                    if (byteFlipCompressed == true)
	                    {
		                    if ((sizeNew%2) == 1)
		                    {
			                    tempBufferNew[sizeNew-0x8] = 0;
			                    sizeNew++;
		                    }

		                    for (int x = 0; x < sizeNew; x=x+2)
		                    {
			                    Byte tempSpot = tempBufferNew[x];
			                    tempBufferNew[x] = tempBufferNew[x+1];
			                    tempBufferNew[x+1] = tempSpot;
		                    }
	                    }

                        b.Write(tempBufferNew, (Int32)start, (Int32)(sizeNew-(start + 8)));

	                    UInt32 fileSizeNew = (UInt32)(sizeNew-(start + 8));
	                    if ((fileSizeNew % 0x8) != 0)
	                    {
		                    for (int x = 0; x < (0x8-(fileSizeNew % 0x8)); x++)
		                    {
			                    if ((game == BANJOKAZOOIE) || (game == BANJOTOOIE))
			                    {
				                    Byte tempZero = 0xAA;
                                    b.Write(tempZero);
			                    }
			                    else
			                    {
				                    Byte tempZero = 0;
				                    b.Write(tempZero);
			                    }
		                    }            		
		                    return true;
                         }   
                    }
		           return false;
	            }
	            else
	            {
		            MessageBox.Show("Error Compressing - GZip didn't spit out a file", "Error");
		            return false;
	            }
            }
            return false;
        }

        public Byte[] OutputDecompressedBuffer(ref int fileSize, ref int compressedSize)
        {
            compressedSize = 0;
            if ((compressedBuffer == null) || (compressedBufferSize < 3))
	            return null;


            if ((((compressedBuffer[0] << 8) | compressedBuffer[1]) != 0x1172) && (((compressedBuffer[0] << 8) | compressedBuffer[1]) != 0x1173) && (((compressedBuffer[0] << 8) | compressedBuffer[1]) != 0x789C) && (((compressedBuffer[0] << 8) | compressedBuffer[1]) != 0x78DA) && (((compressedBuffer[0] << 24) | (compressedBuffer[1]<<16) | (compressedBuffer[2]<<8) | (compressedBuffer[3])) != 0x1F8B0800) && (((compressedBuffer[0] << 24) | (compressedBuffer[1]<<16) | (compressedBuffer[2]<<8) | (compressedBuffer[3])) != 0x1F8B0808) && (game != BLASTCORPS) && (game != BANJOTOOIE) && (game != CONKER)  && (game != TOPGEARRALLY) && (game != JFG) && (game != DKR) && (game != JFGKIOSK) && (game != MICKEYSPEEDWAY))
            {
	            MessageBox.Show("Not 1172/1173/1F8B0800/1F8B0808 Compressed", "Error");
	            return null;
            }

            bitsCache = 0;
            bitsRemain = 0;
            if ((game == GOLDENEYE) || (game == KILLERINSTINCT) || (game == MILO) || (game == STUNTRACER64))
	            bytesIndex = 2;
            else if (game == PD)
	            bytesIndex = 5;
            else if (game == BANJOKAZOOIE)
	            bytesIndex = 6;
            else if ((game == DONKEYKONG64) || (game == DONKEYKONG64KIOSK) || (game == BLASTCORPS))
	            bytesIndex = 0xA;
            else if ((game == BANJOTOOIE))
	            bytesIndex = 0x2;
            else if (game == CONKER)
	            bytesIndex = 4;
            else if (game == TOPGEARRALLY)
	            bytesIndex = 0xE;
            else if ((game == JFG) || (game == JFGKIOSK) || (game == DKR) || (game == MICKEYSPEEDWAY))
	            bytesIndex = 0x5;


            if (((game == DONKEYKONG64) || (game == DONKEYKONG64KIOSK) || (game == BLASTCORPS)) && (((compressedBuffer[0] << 24) | (compressedBuffer[1]<<16) | (compressedBuffer[2]<<8) | (compressedBuffer[3])) == 0x1F8B0808))
            {
	            while (compressedBuffer[bytesIndex] != 0)
		            bytesIndex++;
	            bytesIndex++;
            }
            unpackTableIndex = 0;
            for (int x = 0; x < 0xFFFF; x++)
            {
	            unpackTable[x].bits = 0;
	            unpackTable[x].flags = 0;
	            unpackTable[x].nextIndex = 0;
	            unpackTable[x].wordValue = 0;
            }

            Byte[] returnBuffer;
            returnBuffer = new Byte[maxByteSize];


            Boolean done = false;
            Byte compressionType;
            fileSize = 0;

            iterationCounter = 0;

            do
            {
	            if (iterationCounter > 268435455)
	            {
		            fileSize = 0;
		            return null;
	            }
	            iterationCounter++;
	            done = Convert.ToBoolean(GetNBits(1));
	            if (bytesIndex >= maxByteSize)
	            {
		            fileSize = 0;
		            return null;
	            }
	            compressionType = Convert.ToByte(GetNBits(2));
	            if (compressionType == 0)
	            {
		            if (!UncompressType0(returnBuffer, ref fileSize))
		            {
			            fileSize = 0;
			            return null;
		            }
	            }
	            else if (compressionType == 1)
	            {
		            if (!UncompressType1(returnBuffer, ref fileSize))
		            {
			            fileSize = 0;
			            return null;
		            }
	            }
	            else if (compressionType == 2)
	            {
		            if (!UncompressType2(returnBuffer, ref fileSize))
		            {
			            fileSize = 0;
			            return null;
		            }
	            }
	            else
	            {
		            fileSize = 0;
			            return null;
	            }
            } while (done != true);

            compressedSize = (Int32)bytesIndex;
            return returnBuffer;	
        }

        Boolean UncompressType0(Byte[] returnBuffer, ref int fileSize)
        {
            // discard bits

            UInt32 discardBits = (UInt32)bitsRemain & 0x7;
            GetNBits((int)discardBits); // discard begins

            UInt16 copyLen = (UInt16)GetNBits(16);
            GetNBits(16); // discarded

            for (int x = 0; x < copyLen; x++)
            {
	            if (fileSize >= maxByteSize)
	            {
		            fileSize = 0;
		            return false;
	            }
	            returnBuffer[fileSize] = (Byte)GetNBits(8);
	            fileSize++;

	            if (iterationCounter > 268435455)
	            {
		            fileSize = 0;
		            return false;
	            }
	            iterationCounter++;
            }

            return true;
        }

        Boolean UncompressType1(Byte[] returnBuffer, ref int fileSize)
        {
            Boolean returnValue1 = false;
            Boolean returnValue2 = false;
            int numBits1 = 0;
            int numBits2 = 0;
            int startIndex1 = 0;
            int startIndex2 = 0;
            CreateGlobalDecompressionTable(0, 0x101, 0, 0, 7, ref returnValue1, ref numBits1, ref startIndex1);
            CreateGlobalDecompressionTable(1, 0, 1, 1, 5, ref returnValue2, ref numBits2, ref startIndex2);
            return DecompressBasedOnTable(startIndex1, startIndex2, numBits1, numBits2, returnBuffer, ref fileSize);
        }

        Boolean UncompressType2(Byte[] returnBuffer, ref int fileSize)
        {
            try
            {

            for (int x = 0; x < 0x13; x++)
            {
	            variableTable[x] = 0;
            }

            tableSize = (ushort)(GetNBits(5)+0x101);
            fiveBits = (byte)(GetNBits(5)+0x1);
            Byte fourBits = (byte)(GetNBits(4)+0x4);

            for (int index = 0; index < fourBits; index++)
            {
	            Byte threeBits =(byte)GetNBits(3);
	            variableTable[bt2Table1B[index]] = threeBits;
            }

            Boolean returnValue1 = false;
            int numBits1 = 0;
            int startIndex1 = 0;

            CreateGlobalDecompressionTable(2, 0x13, 2, 2, 7, ref returnValue1, ref numBits1, ref startIndex1);

            wordTable = new UInt32[0xFFFF];

            int wordTableSpot = 0;

            UInt32 lastWritten = 0;
            while (wordTableSpot < (tableSize + fiveBits))
            {

	            if (iterationCounter > 268435455)
	            {
		            fileSize = 0;
		            return false;
	            }
	            iterationCounter++;

	            UInt32 tableIndex = GetNBitsAndPreserve(numBits1);
	            if ((startIndex1 + tableIndex) > 0xFFFF)
	            {
		            fileSize = 0;
		            return false;
	            }
	            int numBits2 = (int)unpackTable[startIndex1 + tableIndex].bits;
	            if (bytesIndex >= maxByteSize)
	            {
		            fileSize = 0;
		            return false;
	            }
	            GetNBits(numBits2);
	            UInt32 wordValue = unpackTable[startIndex1 + tableIndex].wordValue;
	            if (unpackTable[startIndex1 + tableIndex].nextIndex == 0)
	            {
		            if (wordValue < 0x10)
		            {
			            lastWritten = wordValue;
			            wordTable[wordTableSpot] = wordValue;
			            wordTableSpot++;
		            }
		            else if (wordValue == 0x10)
		            {
			            int repeatLen = (int)(GetNBits(2) + 3);
			            for (int index = 0; index < repeatLen; index++)
			            {
				            wordTable[wordTableSpot] = lastWritten;
				            wordTableSpot++;
			            }
		            }
		            else if (wordValue == 0x11)
		            {
			            int repeatLen = (int)(GetNBits(3) + 3);
			            for (int index = 0; index < repeatLen; index++)
			            {
				            wordTable[wordTableSpot] = 0;
				            wordTableSpot++;					
			            }
		            }
		            else
		            {
			            int repeatLen = (int)(GetNBits(7) + 0xB);
			            for (int index = 0; index < repeatLen; index++)
			            {
				            wordTable[wordTableSpot] = 0;
				            wordTableSpot++;					
			            }
		            }
	            }
            }
            Boolean returnValue2 = false;
            Boolean returnValue3 = false;
            int numBits22 = 0;
            int numBits3 = 0;
            int startIndex2 = 0;
            int startIndex3 = 0;

            CreateGlobalDecompressionTable(3, 0x101, 0, 0, 9, ref returnValue2, ref numBits22, ref startIndex2);

            CreateGlobalDecompressionTable(4, 0, 1, 1, 6, ref returnValue3, ref numBits3, ref startIndex3);
            DecompressBasedOnTable(startIndex2, startIndex3, numBits22, numBits3, returnBuffer, ref fileSize);
	        wordTable = null;

            } catch (Exception e)
            {
                String error = e.ToString();
                MessageBox.Show(e.StackTrace);
	            fileSize = 0;
	            return false;
            }
            return true;
        }

        void CreateGlobalDecompressionTable(int bit1TableChoice, int size2, int bit12STableSChoice, int bit12BTableChoice, int numBits, ref Boolean returnValue, ref int numReturnBits, ref int returnStartIndex)
        {
            //if (bit1TableChoice == 0) bt1Table1 else bt1Table2
            //if (bit12STableSChoice == 0) bt12Table1S else bt12Table2S
            //if (bit12BTableChoice == 0) bt12Table1B else bt12Table2B
            String temp; // temp var del later

            tableEntry localTableEntry;
            localTableEntry.bits = 0;
            localTableEntry.flags = 0;
            localTableEntry.nextIndex = 0;
            localTableEntry.wordValue = 0;

            int table1Size = 0;

            int returnIndex = -1;

            UInt32[] seventeenints1 = new UInt32[17];
            for (int x = 0; x < 17; x++)
	            seventeenints1[x] = 0;

            if (bit1TableChoice == TABLE1)
            {
	            table1Size = 288;
	            for (int x = 0; x < 288; x++)
	            {
		            seventeenints1[bt1Table1[x]]++;
	            }
            }
            else if (bit1TableChoice == TABLE2)
            {
	            table1Size = 30;
	            for (int x = 0; x < 30; x++)
	            {
		            seventeenints1[bt1Table2[x]]++;
	            }
            }
            else if (bit1TableChoice == VARIABLETABLE)
            {
	            table1Size = 0x13;		
	            for (int x = 0; x < 0x13; x++)
	            {
		            seventeenints1[variableTable[x]]++;			
	            }
            }
            else if (bit1TableChoice == WORDTABLEBEGIN)
            {
	            table1Size = tableSize;		
	            for (int x = 0; x < table1Size; x++)
	            {
		            seventeenints1[wordTable[x]]++;			
	            }
            }
            else if (bit1TableChoice == WORDTABLEEND)
            {
	            table1Size = ((tableSize + fiveBits) - tableSize);
	            for (int x = 0; x < table1Size; x++)
	            {
		            seventeenints1[wordTable[tableSize + x]]++;			
	            }
            }

            int firstBit = 1;
            while (seventeenints1[firstBit] == 0)
	            firstBit++;

            int lastBit = 16;	
            while (seventeenints1[lastBit] == 0)
	            lastBit--;

            if (numBits < firstBit)
	            numBits = firstBit;
            if (numBits > lastBit)
	            numBits = lastBit;

            UInt32 v1temp = (uint)(1<<firstBit);
            if (firstBit != lastBit)
            {
	            for (int bitNum = firstBit; bitNum < lastBit; bitNum++)
	            {
		            v1temp = ((v1temp - seventeenints1[bitNum])*2);
	            }	
            }

            int oldLastBitCount = (int)seventeenints1[lastBit];
            seventeenints1[lastBit] = v1temp;
            v1temp = (uint)(v1temp - oldLastBitCount);

            UInt32[] seventeenints2 = new UInt32[17];
            for (int x = 0; x < 17; x++)
	            seventeenints2[x] = 0;

            int accumulator = 0;
            for (int index = 1; index < lastBit; index++)
            {
	            accumulator = (int)(accumulator + seventeenints1[index]);
	            seventeenints2[index+1] = (uint)accumulator;
            }


            UInt32[] moreWords;
            moreWords = new UInt32[table1Size];
            int moreWordsIndex = 0;
            int newIndex = 0;

            for (int x = 0; x < table1Size; x++)
            {
	            moreWords[x] = 0;
            }

            for (int x = 0; x < table1Size; x++)
            {

	            if (bit1TableChoice == TABLE1)
	            {
		            if ((bt1Table1[x]) != 0)
		            {
			            moreWords[seventeenints2[bt1Table1[x]]] = (uint)newIndex;
			            seventeenints2[bt1Table1[x]]++;
		            }
	            }
	            else if (bit1TableChoice == TABLE2)
	            {
		            if ((bt1Table2[x]) != 0)
		            {
			            moreWords[seventeenints2[bt1Table2[x]]] = (uint)newIndex;
			            seventeenints2[bt1Table2[x]]++;
		            }
	            }
	            else if (bit1TableChoice == VARIABLETABLE)
	            {
		            if ((variableTable[x]) != 0)
		            {
			            moreWords[seventeenints2[variableTable[x]]] = (uint)newIndex;
			            seventeenints2[variableTable[x]]++;	
		            }
	            }
	            else if (bit1TableChoice == WORDTABLEBEGIN)
	            {
		            if ((wordTable[x]) != 0)
		            {
			            moreWords[seventeenints2[wordTable[x]]] = (uint)newIndex;
			            seventeenints2[wordTable[x]]++;
		            }
	            }
	            else if (bit1TableChoice == WORDTABLEEND)
	            {
		            if ((wordTable[tableSize + x]) != 0)
		            {
			            moreWords[seventeenints2[wordTable[tableSize + x]]] = (uint)newIndex;
			            seventeenints2[wordTable[tableSize + x]]++;
		            }
	            }
	            newIndex++;
            }

            int stemp2_v1 = -numBits;
            int blockNum = -1;
            int bitPattern = 0;

            int[] unpackTableStarts = new int[0x20000];
            int unpackTableStartsIndex = -1;

            UInt32 temp_a3 = 0;
            int thisTableStart = 0;

            for (int bitNum = firstBit; bitNum < (lastBit+1); bitNum++)
            {
	            int iterationsLeft = (int)seventeenints1[bitNum];
	            UInt32 lv34 = (uint)(1<<(bitNum-1));
	            int moreWordsIndex2 = table1Size;

	            while (iterationsLeft > 0)
	            {
		            if (iterationsLeft < 0)
			            break;
		            stemp2_v1 = stemp2_v1 + numBits;
		            while (stemp2_v1 < bitNum)
		            {
			            blockNum++;

			            UInt32 temp_t0 = 0;

			            if (numBits < (lastBit-stemp2_v1))
				            temp_t0=(uint)numBits;
			            else
				            temp_t0 = (uint)(lastBit-stemp2_v1);

			            temp_a3 = (uint)(bitNum - stemp2_v1);

			            if (iterationsLeft < (1<<((int)temp_a3)))
			            {
				            UInt32 another_var_v1= (UInt32)((1 << ((int)temp_a3)) - iterationsLeft);
				            temp_a3++;

				            newIndex = bitNum + 1;
				            while (temp_a3 < temp_t0)
				            {
                                if (newIndex >= seventeenints1.Length) // change for C#
                                    break;

					            if (seventeenints1[newIndex] < (another_var_v1*2))
					            {
						            temp_a3++;
						            another_var_v1 = another_var_v1*2 - seventeenints1[newIndex];
					            }
					            newIndex++;
				            }
			            }
			            if (returnIndex==-1)
				            returnIndex=unpackTableIndex + 1;
        				
			            unpackTableStartsIndex++;
			            unpackTableStarts[unpackTableStartsIndex] = (unpackTableIndex+1);
        				
			            thisTableStart = unpackTableIndex + 1;

			            if (blockNum != 0)
			            {
				            seventeenints2[blockNum] = (uint)bitPattern;
				            localTableEntry.bits = (uint)numBits;
				            localTableEntry.flags = (byte)(temp_a3 + 0x10);
				            localTableEntry.nextIndex= unpackTableIndex + 1;
				            localTableEntry.wordValue = 0xFFFFFFFF; // was -1
				            unpackTable[(bitPattern>>(stemp2_v1-numBits))+unpackTableStarts[blockNum-1]].bits = localTableEntry.bits;
				            unpackTable[(bitPattern>>(stemp2_v1-numBits))+unpackTableStarts[blockNum-1]].flags = localTableEntry.flags;
				            unpackTable[(bitPattern>>(stemp2_v1-numBits))+unpackTableStarts[blockNum-1]].wordValue = localTableEntry.wordValue;
				            unpackTable[(bitPattern>>(stemp2_v1-numBits))+unpackTableStarts[blockNum-1]].nextIndex = localTableEntry.nextIndex;
			            }

			            unpackTableIndex=unpackTableIndex + ((1<<(int)temp_a3)+1);
			            stemp2_v1+=numBits;
		            }
		            stemp2_v1 = stemp2_v1 - numBits;

		            localTableEntry.bits = (uint)(bitNum - stemp2_v1);
		            localTableEntry.nextIndex = 0;
		            if (moreWordsIndex >= moreWordsIndex2)
			            localTableEntry.flags = 0x63;
		            else
		            {
			            UInt32 tempWord = moreWords[moreWordsIndex];
			            if (tempWord<size2)
			            {
				            if (tempWord >= 0x100)
					            localTableEntry.flags = 0xf;
				            else
					            localTableEntry.flags = 0x10;
				            localTableEntry.wordValue = tempWord;
			            }
			            else
			            {
				            if (bit12STableSChoice == TABLE1)
				            {
					            localTableEntry.flags = (Byte)bt12Table1B[moreWords[moreWordsIndex]-size2];
					            localTableEntry.wordValue = bt12Table1S[moreWords[moreWordsIndex]-size2];
				            }
				            else if (bit12STableSChoice == TABLE2)
				            {
					            localTableEntry.flags = (Byte)bt12Table2B[moreWords[moreWordsIndex]-size2];
					            localTableEntry.wordValue = bt12Table2S[moreWords[moreWordsIndex]-size2];
				            }
				            else if (bit12STableSChoice == VARIABLETABLE)
				            {
					            // shouldn't happen

				            }
			            }
			            moreWordsIndex++;
		            }
        		
		            UInt32 nu_accum_a3 = (uint)(bitPattern >> stemp2_v1);
		            UInt32 stride_v0 = (uint)(1<<(bitNum - stemp2_v1));
		            /*if (thisTableStart==744)
		            {
			            if thisTableStart+nu_accum_a3==758
			            {
				            if stride_v0==16:
				            {
					            debugIt=1
				            }
			            }
		            }*/
		            while ((1<<(int)temp_a3) > nu_accum_a3)
		            {
			            if ((thisTableStart+nu_accum_a3) > 0xFFFF)
			            {
				            return;
			            }
			            unpackTable[thisTableStart+nu_accum_a3].bits = localTableEntry.bits;
			            unpackTable[thisTableStart+nu_accum_a3].flags = localTableEntry.flags;
			            unpackTable[thisTableStart+nu_accum_a3].wordValue = localTableEntry.wordValue;
			            unpackTable[thisTableStart+nu_accum_a3].nextIndex = localTableEntry.nextIndex;
			            nu_accum_a3 = nu_accum_a3 + stride_v0;
		            }

		            UInt32 tempLv=lv34;
        			
		            while ((bitPattern & tempLv) > 0)
		            {
			            bitPattern = (int)(bitPattern ^ tempLv);
			            tempLv = tempLv >> 1;
		            }
		            bitPattern = (int)(bitPattern ^ tempLv);
		            while((bitPattern & ((1 << stemp2_v1)-1)) != seventeenints2[blockNum])
		            {
			            blockNum = blockNum- 1;
			            stemp2_v1=0;
		            }

		            iterationsLeft = iterationsLeft - 1;
	            }
            }
            moreWords = null;
            if (v1temp > 0)
            {
	            returnValue = (0<(lastBit^1));
	            numReturnBits = numBits;
	            returnStartIndex = returnIndex;
            }
            else
            {
	            returnValue = false;
	            numReturnBits = numBits;
	            returnStartIndex = returnIndex;
            }
        }

        Boolean DecompressBasedOnTable(int startIndex1, int startIndex2, int bitLen1, int bitLen2, Byte[] returnBuffer, ref int fileSize)
        {
            UInt32 index = 0;
            Boolean exitFlag = true;

            try
            {

            while (exitFlag)
            {

	            if (iterationCounter > 268435455)
	            {
		            fileSize = 0;
		            return false;
	            }
	            iterationCounter++;

	            if (bytesIndex >= maxByteSize)
	            {
		            fileSize = 0;
		            return false;
	            }
	            index = GetNBitsAndPreserve(bitLen1);
	            if ((startIndex1 + index) > 0xFFFF)
	            {
		            fileSize = 0;
		            return false;
	            }
	            tableEntry entry = unpackTable[startIndex1 + index];

	            while (entry.flags > 0x10)
	            {
		            if (iterationCounter > 268435455)
		            {
			            fileSize = 0;
			            return false;
		            }
		            iterationCounter++;

		            if (bytesIndex >= maxByteSize)
		            {
			            fileSize = 0;
			            return false;
		            }
		            GetNBits((int)entry.bits); // discard
		            index = GetNBitsAndPreserve(entry.flags-0x10);
		            if ((entry.nextIndex+index) > 0xFFFF)
		            {
			            fileSize = 0;
			            return false;
		            }
		            entry = unpackTable[entry.nextIndex+index];
	            }
	            if (bytesIndex >= maxByteSize)
	            {
		            fileSize = 0;
		            return false;
	            }
	            GetNBits((int)entry.bits); // discard
        		
	            if (entry.flags==0x10)
	            {
		            if (fileSize >= maxByteSize)
		            {
			            fileSize = 0;
			            return false;
		            }
		            returnBuffer[fileSize] = (Byte)entry.wordValue;
		            fileSize++;
	            }
	            else if (entry.flags < 0xf)
	            {
		            UInt32 copyLen = entry.wordValue + GetNBits(entry.flags);
		            UInt32 index2 = GetNBitsAndPreserve(bitLen2);
		            if ((startIndex2+index2) > 0xFFFF)
		            {
			            fileSize = 0;
			            return false;
		            }
		            tableEntry entry2 = unpackTable[startIndex2+index2];
		            while (entry2.flags>0x10)
		            {

			            if (iterationCounter > 268435455)
			            {
				            fileSize = 0;
				            return false;
			            }
			            iterationCounter++;

			            if (bytesIndex >= maxByteSize)
			            {
				            fileSize = 0;
				            return false;
			            }
			            GetNBits((int)entry2.bits); // discard
			            index2 = GetNBitsAndPreserve(entry2.flags-0x10);
			            if ((entry2.nextIndex+index2) > 0xFFFF)
			            {
				            fileSize = 0;
				            return false;
			            }
			            entry2 = unpackTable[entry2.nextIndex+index2];
		            }
		            if (bytesIndex >= maxByteSize)
		            {
			            fileSize = 0;
			            return false;
		            }
		            GetNBits((int)entry2.bits); // discard

		            UInt32 endOffset1 = entry2.wordValue;
		            UInt32 endOffset2 = GetNBits(entry2.flags);
		            UInt32 start = (uint)(fileSize-endOffset1-endOffset2);
		            UInt32 end = start + copyLen;
		            for (int x = (int)start; x < end; x++)
		            {
			            if ((((Int32) start) < 0) || ((((Int32) end) < 0)) || ((start > maxByteSize)) || ((end > maxByteSize)))
			            {
				            fileSize = 0;
				            return false;
			            }
			            returnBuffer[fileSize] = returnBuffer[x];
			            fileSize++;
		            }
	            }
	            else
		            exitFlag = false;
            }

            } catch (Exception)
            {
	            return false;
            }
            return true;
        }
    }
}
