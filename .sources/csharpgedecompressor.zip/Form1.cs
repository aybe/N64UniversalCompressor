﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace CSharpGEDecompressor
{
    public partial class CSharpGEDecomprssor : Form
    {
        public CSharpGEDecomprssor()
        {
            InitializeComponent();
            comboBoxGame.SelectedIndex = 2;
        }

        private void buttonDecompress_Click(object sender, EventArgs e)
        {
            FileDialog fileDlg = new OpenFileDialog();
            fileDlg.DefaultExt = "1172";
            if (fileDlg.ShowDialog() == DialogResult.OK)
            {
                GECompression gecompress = new GECompression();
                gecompress.SetPath(Directory.GetCurrentDirectory());
                gecompress.SetGame(comboBoxGame.SelectedIndex);
                using (BinaryReader b = new BinaryReader(File.Open(fileDlg.FileName, FileMode.Open, FileAccess.Read, FileShare.Read)))
	            {
	                int size = Convert.ToInt32(b.BaseStream.Length);

                    byte[] tempBufferTemp = b.ReadBytes((Int32)size);
                    gecompress.SetCompressedBuffer(tempBufferTemp, size);
                    int decompressedSize = 0;

                    byte[] results = gecompress.OutputDecompressedBuffer(ref decompressedSize, ref size);

                    if (results == null)
                    {
                        MessageBox.Show("Error decompressing");
                        return;
                    }
                    using (BinaryWriter bw = new BinaryWriter(File.Open((fileDlg.FileName + ".bin"), FileMode.Create)))
                    {
                        bw.Write(results, (Int32)0, (Int32)decompressedSize);
                        bw.Flush();
                        bw.Close();
                    }
                 }
                
            }
        }

        private void buttonCompress_Click(object sender, EventArgs e)
        {
            FileDialog fileDlg = new OpenFileDialog();
            fileDlg.DefaultExt = "bin";
            if (fileDlg.ShowDialog() == DialogResult.OK)
            {

                FileDialog fileDlg2 = new SaveFileDialog();
                fileDlg2.DefaultExt = "1172";
                if (fileDlg2.ShowDialog() == DialogResult.OK)
                {
                    GECompression gecompress = new GECompression();
                    gecompress.SetPath(Directory.GetCurrentDirectory());
                    gecompress.SetGame(comboBoxGame.SelectedIndex);
                    gecompress.CompressGZipFile(fileDlg.FileName, fileDlg2.FileName, false);
                }
            }
        }

        private void comboBoxGame_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxGame.Text.Contains("BANJOTOOIE"))
            {
                labelFileNumber.Visible = true;
                textBoxFileNumber.Visible = true;
                buttonDecompressEncrypted.Visible = true;
                buttonCompressEncrypted.Visible = true;
                buttonDecompress.Visible = true;
            }
        }

        private void buttonDecompressEncrypted_Click(object sender, EventArgs e)
        {
            FileDialog fileDlg = new OpenFileDialog();
            fileDlg.DefaultExt = "1172";
            if (fileDlg.ShowDialog() == DialogResult.OK)
            {
                GECompression gecompress = new GECompression();
                gecompress.SetPath(Directory.GetCurrentDirectory());
                gecompress.SetGame(comboBoxGame.SelectedIndex);
                using (BinaryReader b = new BinaryReader(File.Open(fileDlg.FileName, FileMode.Open, FileAccess.Read, FileShare.Read)))
                {
                    int size = Convert.ToInt32(b.BaseStream.Length);

                    byte[] tempBufferTemp = b.ReadBytes((Int32)size);

                    int fileNumber = Convert.ToInt32(textBoxFileNumber.Text, 16);

                    BTDecryption.DecryptBTFile(fileNumber, tempBufferTemp, tempBufferTemp, tempBufferTemp.Length);

                    gecompress.SetCompressedBuffer(tempBufferTemp, size);
                    int decompressedSize = 0;

                    byte[] results = gecompress.OutputDecompressedBuffer(ref decompressedSize, ref size);

                    if (results == null)
                    {
                        MessageBox.Show("Error decompressing");
                        return;
                    }
                    using (BinaryWriter bw = new BinaryWriter(File.Open((fileDlg.FileName + ".bin"), FileMode.Create)))
                    {
                        bw.Write(results, (Int32)0, (Int32)decompressedSize);
                        bw.Flush();
                        bw.Close();
                    }
                }

            }
        }

        private void buttonCompressEncrypted_Click(object sender, EventArgs e)
        {
            FileDialog fileDlg = new OpenFileDialog();
            fileDlg.DefaultExt = "bin";
            if (fileDlg.ShowDialog() == DialogResult.OK)
            {

                FileDialog fileDlg2 = new SaveFileDialog();
                fileDlg2.DefaultExt = "1172";
                if (fileDlg2.ShowDialog() == DialogResult.OK)
                {
                    GECompression gecompress = new GECompression();
                    gecompress.SetPath(Directory.GetCurrentDirectory());
                    gecompress.SetGame(comboBoxGame.SelectedIndex);
                    gecompress.CompressGZipFile(fileDlg.FileName, fileDlg2.FileName, false);

                    int fileNumber = Convert.ToInt32(textBoxFileNumber.Text, 16);

                    byte[] tempBufferTemp = null;
                    int size = 0;

                    using (BinaryReader b = new BinaryReader(File.Open(fileDlg2.FileName, FileMode.Open, FileAccess.Read, FileShare.Read)))
                    {
                        size = Convert.ToInt32(b.BaseStream.Length);
                        tempBufferTemp = b.ReadBytes((Int32)size);
                    }

                    BTDecryption.DecryptBTFile(fileNumber, tempBufferTemp, tempBufferTemp, tempBufferTemp.Length);

                    using (BinaryWriter bw = new BinaryWriter(File.Open((fileDlg2.FileName), FileMode.Create)))
                    {
                        bw.Write(tempBufferTemp, (Int32)0, (Int32)size);
                        bw.Flush();
                        bw.Close();
                    }
                }
            }
        }
    }
}
