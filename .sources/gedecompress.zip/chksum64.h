#pragma once

class CheckSumN64
{
public:
	CheckSumN64(void);
	~CheckSumN64(void);

	int ConvertROM(CString inputFileName);
};
