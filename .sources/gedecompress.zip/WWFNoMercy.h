// BY ZOINKITY, PORT UNTESTED
#pragma once

class CWWFNoMercy
{
public:
	CWWFNoMercy(void);
	~CWWFNoMercy(void);
	int decWWFNoMercy(unsigned char* data, int& compressedSize, int dec_s, unsigned char* output);
};
