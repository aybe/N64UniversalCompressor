// Spinout
#pragma once

class ERZ
{
public:
	int decode(unsigned char * src, int filesize, unsigned char* result, int& fileSizeCompressed);
};
