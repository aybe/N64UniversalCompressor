// Spinout
#pragma once

class YAY0
{
public:
	int decodeAll(unsigned char * src, unsigned char* result, int& fileSizeCompressed);
};
